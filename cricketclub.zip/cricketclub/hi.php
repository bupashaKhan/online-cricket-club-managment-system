<!DOCTYPE html>
<html>
<body>

<h1> Thanks for your feedback</h1>

<?php
//echo "Hello World!";
?>

</body>
</html>