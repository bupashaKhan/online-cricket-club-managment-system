    <!-- footer part start-->

    <footer class="copyright_part">
        <div class="container">
            <div class="row align-items-center">
                <p class="footer-text m-0 col-lg-8 col-md-12"><!-- Link back to Colorlib can't be removed. Template is licensed under CC BY 3.0. -->
Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved |<i class="ti-heart" aria-hidden="true"></i> by <a href="" target="_blank">Raiyan Rafsan
</a>
</p>
                <div class="col-lg-4 col-md-12 text-center text-lg-right footer-social">
                    <a href="https://www.facebook.com/raiyanrafsanrain/" target="_blank"><i class="ti-facebook"></i></a>
                    <a href="https://twitter.com/RaiyanRafsan3" target="_blank"> <i class="ti-twitter"></i> </a>
                    <a href="https://www.instagram.com/raiyan_rafsan_sardar/" target="_blank"><i class="ti-instagram"></i></a>
                    <a href="https://github.com/bupashaKhan/online-cricket-club-managment-system" target="_blank"><i class="ti-github"></i></a>
                </div>
            </div>
        </div>
    </footer>
    <!-- footer part end-->

