# Cricket Club Management System
The Cricket Club management system consists of various online booking and management functionaries needed by a cricket club. It provides various options like ground bookings, member registrations, notice posting, member registration, batch registration and more. The Cricket Club management system assures efficient management and maintains the functioning on a cricket club. 	The Cricket Club management system consists of various online booking and management functionaries needed by a cricket club. It provides various options like ground bookings, member registrations, notice posting, member registration, batch registration and more. The Cricket Club management system assures efficient management and maintains the functioning on a cricket club. 

The project consists of the following features:

### Ground Booking: 
The user may fill and apply for club ground booking using an online form. Once the admin approves the application, the ground is booked accordingly.

### Member Registration:
People may register for the club membership.

### Batch Registration:
People may register for various cricket training batches through the website contact form.

### Notices: 
Recent notices can be seen on the start page as they are posted by the admin.

### Admin Login: 
Admin can approve and disapprove various ground booking requests, may check various members of the club and also people registered for various batches.